let express = require('express');
let app = express();



var mysql = require("mysql");
var connection = mysql.createConnection({
    host    : 'localhost',
    user    : 'root',
    password: 'root',
    database: 'labo6',
});

connection.connect(function(error){if (error) console.log(error);});

app.use(express.urlencoded({extended: true}));
//app.use(express.static('css'));

let session = require('express-session');
app.use(session({
    secret: 'my secret',
    resave: false,
    saveUninitialized: true
    })
);

//ouvre la page pour se connecter
app.get('/LogIn', (req, res) => {
    res.render('LogIn.ejs');
});

var a=0;
var b=0;

//lorque on appuye sur le bouton pour se connecter avant d'avoir finaliser on est renvoyé sur la page formation sinon on peut envoyer les données
app.post('/formation1', (req, res) => {

    if (b===0){
    req.session.pseudo = req.body.pseudo;
    a=1;
    res.redirect('/formation');
    }
    else {
        req.session.pseudo = req.body.pseudo;
        res.redirect('/SendData')
    }
});

//On met dans une list les id des formations voulues
var test =[];
app.get('/formation2/:i', (req, res) => {
    let i =req.params.i-1 ;
    test.push(i)
    res.redirect('/formation');
});

//On affiche la page formation en recevant les formation proveant de la database
app.get('/formation', (req, res) => {
    connection.query("select * from formation;", function(error, result) {
        if (error) console(error);
        res.render('formation.ejs', {formation: result});
    });
});

//On affiche le panier
app.get('/panier', (req, res) => {
    connection.query("select * from formation;", function(error, result) {
        if (error) console(error);
    res.render('panier.ejs', {test, formation: result});
    });
});

//Bouton pour supprimer une formation qui a été ajouté
app.get('/supprimer/:i', (req, res) => {
    let i =req.params.i-1 ;
    test.splice(i,1);
    res.redirect('/panier');
});

//Lorsqu'on appuye sur le bouton finaliser on vérifie si l'utilisateur s'est déjà connecté
app.get('/finaliser', (req, res) => {
    if (a===0) {
        b=1;
        res.redirect('/LogIn');
    }
    else {
        res.redirect('/SendData');
    }
});

//Envoye les données au serveur
app.get('/SendData', (req, res) => {
    for (elem =0; elem<3; elem++) {
        test.push(-1);
    }
        
    let student = {"pseudo":req.session.pseudo ,"idformation1":test[0]+1, "idformation2":test[1]+1, "idformation3":test[2]+1}
    connection.query("INSERT INTO student SET ?", student, function(err, result) {
        if (err) console.log(err);
        test=[];       
        res.send("Enregistrement dans la database OK");
    });
});

app.listen(8000, function () {
    console.log('runnings on port 8000');
})